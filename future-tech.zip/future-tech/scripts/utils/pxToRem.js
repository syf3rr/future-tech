const pxToRem = (pixels) => {
    return pixels / 16
}

export default pxToRem